new Vue({
  el: '#example',
  data: { hello: 'Hello World!' }
})
